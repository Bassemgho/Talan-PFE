import events from '../models/event.js'
import {io } from '../index.js'
let socketList = {}
const sockethandler =  (socket)=>{
  socket.on('disconnect', () => {
      socket.disconnect();
      console.log('User disconnected!');
    });
  socket.on('BE-check-user', ({ roomId, userName }) => {
    let error = false;

    io.sockets.in(roomId).clients((err, clients) => {
      clients.forEach((client) => {
        if (socketList[client] == userName) {
          error = true;
        }
      });
      socket.emit('FE-error-user-exist', { error });
    });
  })
  socket.on('BE-join-room',async ({eventid})=>{
    socket.join(eventid)

    socketList[socket.id.toString()]= {userName:`${socket.user.firstname} ${socket.user.lastname}`,video:true, audio:true}
    console.log('soocketlist',socketList);
    try {
      const users = []
      // const clients  =await io.in(eventid).fetchSockets();
      const clients = io.sockets.adapter.rooms.get(eventid);
      clients.forEach((client) => {
        users.push({userId:client,info:socketList[client]})
      });
console.log(users);
     socket.broadcast.to(eventid).emit('FE-user-join', users);

    } catch (e) {
      io.sockets.in(eventid).emit('FE-error-user-exist', { err: true ,message:e.message});
      console.log(e.message);
    }

    // io.sockets.in(eventid).clients((err,  clients)=>{
    //   try {
    //     const users = [];
    //     clients.forEach((client) => {
    //       users.push({userId:client,info:socketList[client]})
    //
    //     });
    //     socket.broadcast.to(eventid).emit('FE-user-join', users);
    //   } catch (e) {
    //     io.sockets.in(roomId).emit('FE-error-user-exist', { err: true });
    //   }
    // })
  });
  socket.on('BE-call-user', ({ userToCall, from, signal }) => {
    io.to(userToCall).emit('FE-receive-call',{
      signal,from,info:socketList[socket.id]

    })

});
socket.on('BE-accept-call', ({ signal, to }) => {
  io.to(to).emit('FE-call-accepted',{signal,answerId:socket.id})
});
socket.on('BE-send-message', ({ eventid, msg, sender }) => {
io.sockets.in(eventid).emit('FE-receive-message', { msg, sender });
});
socket.on('BE-leave-room', ({ eventid, leaver }) => {
  delete socketList[socket.id];
    socket.broadcast
      .to(roomId)
      .emit('FE-user-leave', { userId: socket.id, userName: [socket.id] });
    io.sockets.sockets[socket.id].leave(eventid);
});

  socket.on('BE-toggle-camera-audio', ({ eventid, switchTarget }) => {
    if (switchTarget === 'video') {
         socketList[socket.id].video = !socketList[socket.id].video;
       } else {
         socketList[socket.id].audio = !socketList[socket.id].audio;
       }
       socket.broadcast
         .to(eventid)
         .emit('FE-toggle-camera', { userId: socket.id, switchTarget });
  });
}
export default sockethandler
