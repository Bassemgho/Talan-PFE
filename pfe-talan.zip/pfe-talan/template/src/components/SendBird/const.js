export const APP_ID = "EFA04A76-651F-42F6-BDD9-E873BF60E605";
// set your own USER_ID and NICKNAME
export const USER_ID = "bassgh";
export const NICKNAME = "bagh";

export default {
  APP_ID,
  USER_ID,
  NICKNAME
};
