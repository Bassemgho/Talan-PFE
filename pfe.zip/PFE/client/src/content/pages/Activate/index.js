/* eslint-disable */

import {Box} from '@mui/material'
const Activate = ()=>{
  return(
    <Box>
      please activate your account
    </Box>
  )
}
export default Activate
